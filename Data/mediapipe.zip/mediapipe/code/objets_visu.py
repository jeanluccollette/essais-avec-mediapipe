import cv2
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
import objets_util


def Traitement():
    ret, trame = capture.read()
    if ret == True:
        rgb_frame = mp.Image(image_format=mp.ImageFormat.SRGB,
                             data=cv2.cvtColor(trame, cv2.COLOR_BGR2RGB))
        detection_result = detector.detect(rgb_frame)
        annotated_image = objets_util.visualize(
            rgb_frame.numpy_view(), detection_result)
        cv2.namedWindow('Objets')
        cv2.imshow('Objets',  cv2.cvtColor(
            annotated_image, cv2.COLOR_RGB2BGR))
    k = cv2.waitKey(10)
# on quitte en tapant la touche ESC
    if k % 256 == 27:
        return True
    else:
        return False


base_options = python.BaseOptions(
    model_asset_path='../tflite_task/efficientdet.tflite')
options = vision.ObjectDetectorOptions(base_options=base_options,
                                       score_threshold=0.5)
detector = vision.ObjectDetector.create_from_options(options)

choix = int(input(
    'Choisir la source :\n0 : webcam0\n1 : webcam1\n2 : fichier image \n3, 4, 5 : fichier video\n'))
match choix:
    case 0:
        capture = cv2.VideoCapture(0)
    case 1:
        capture = cv2.VideoCapture(1)
    case 2:
        capture = cv2.VideoCapture('../images_videos/cat_and_dog.jpg')
    case 3:
        capture = cv2.VideoCapture('../images_videos/news_interview.wmv')
    case 4:
        capture = cv2.VideoCapture('../images_videos/768x576.avi')
    case 5:
        capture = cv2.VideoCapture(
            '../images_videos/187test_de_camra_embarqu_en_voiture.mp4')
    case _:
        exit()

if capture.isOpened() == False:
    print('source inexistante')
    capture.release()
    cv2.destroyAllWindows()
else:
    print('Touche ESC pour quitter')
    while Traitement() == False:
        pass
    capture.release()
    cv2.destroyAllWindows()
