import cv2
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
import visage_util


def Traitement():
    ret, trame = capture.read()
    if ret == True:

        rgb_frame = mp.Image(image_format=mp.ImageFormat.SRGB,
                             data=cv2.cvtColor(trame, cv2.COLOR_BGR2RGB))
        detection_result = detector.detect(rgb_frame)
        annotated_image = visage_util.draw_landmarks_on_image(
            rgb_frame.numpy_view(), detection_result)
        cv2.namedWindow('Visage')
        cv2.imshow('Visage',  cv2.cvtColor(
            annotated_image, cv2.COLOR_RGB2BGR))
    k = cv2.waitKey(10)
# on quitte en tapant la touche ESC
    if k % 256 == 27:
        return True
    else:
        return False


base_options = python.BaseOptions(
    model_asset_path='../tflite_task/face_landmarker_v2_with_blendshapes.task')
options = vision.FaceLandmarkerOptions(base_options=base_options,
                                       output_face_blendshapes=True,
                                       output_facial_transformation_matrixes=True,
                                       num_faces=1)
detector = vision.FaceLandmarker.create_from_options(options)

choix = int(input(
    'Choisir la source :\n0 : webcam0\n1 : webcam1\n2 : fichier image \n3 : fichier video\n'))
match choix:
    case 0:
        capture = cv2.VideoCapture(0)
    case 1:
        capture = cv2.VideoCapture(1)
    case 2:
        capture = cv2.VideoCapture('../images_videos/business-person.jpg')
    case 3:
        capture = cv2.VideoCapture('../images_videos/news_interview.wmv')
    case _:
        exit()

if capture.isOpened() == False:
    print('source inexistante')
    capture.release()
    cv2.destroyAllWindows()
else:
    print('Touche ESC pour quitter')
    while Traitement() == False:
        pass
    capture.release()
    cv2.destroyAllWindows()
